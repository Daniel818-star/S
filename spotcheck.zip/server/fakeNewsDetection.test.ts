import { describe, expect, it, vi, beforeEach } from "vitest";
import { analyzeNewsContent, extractTextFromImage, Reference } from "./fakeNewsDetection";

// Mock the LLM and Data API modules
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(async (params: any) => {
    // Mock response for image extraction
    if (params.messages?.[0]?.content?.[0]?.type === "image_url") {
      return {
        choices: [
          {
            message: {
              content: "Breaking News: Scientists discover new element",
            },
          },
        ],
      };
    }

    // Mock response for analysis
    return {
      choices: [
        {
          message: {
            content: JSON.stringify({
              confidencePercentage: 75,
              isLikelyFake: true,
              analysis:
                "This claim appears to be fabricated. The description lacks specific details about the element, and no credible scientific sources have reported this discovery.",
              supportingReferenceIndices: [],
              contradictingReferenceIndices: [0, 1],
            }),
          },
        },
      ],
    };
  }),
}));

vi.mock("./_core/dataApi", () => ({
  callDataApi: vi.fn(async () => {
    return {
      results: [
        {
          source: "Nature",
          title: "Recent Element Discoveries",
          url: "https://nature.com/elements",
          snippet: "No new elements have been discovered this year",
        },
        {
          source: "Science Magazine",
          title: "Periodic Table Updates",
          url: "https://science.com/periodic",
          snippet: "The periodic table remains unchanged",
        },
      ],
    };
  }),
}));

describe("fakeNewsDetection", () => {
  describe("extractTextFromImage", () => {
    it("should extract text from an image URL using LLM vision", async () => {
      const imageUrl = "https://example.com/image.jpg";
      const result = await extractTextFromImage(imageUrl);

      expect(result).toBe("Breaking News: Scientists discover new element");
    });

    it("should handle image extraction errors gracefully", async () => {
      const { invokeLLM } = await import("./_core/llm");
      vi.mocked(invokeLLM).mockRejectedValueOnce(new Error("API Error"));

      await expect(extractTextFromImage("https://example.com/image.jpg")).rejects.toThrow(
        "API Error"
      );
    });
  });

  describe("analyzeNewsContent", () => {
    it("should analyze news content and return confidence percentage", async () => {
      const newsContent = "Scientists discover new element";
      const category = "Science";

      const result = await analyzeNewsContent(newsContent, category);

      expect(result).toHaveProperty("confidencePercentage");
      expect(result).toHaveProperty("isLikelyFake");
      expect(result).toHaveProperty("analysis");
      expect(result).toHaveProperty("supportingReferences");
      expect(result).toHaveProperty("contradictingReferences");
      expect(result).toHaveProperty("allReferences");
    });

    it("should correctly categorize supporting and contradicting references", async () => {
      const newsContent = "Scientists discover new element";
      const category = "Science";

      const result = await analyzeNewsContent(newsContent, category);

      expect(result.confidencePercentage).toBe(75);
      expect(result.isLikelyFake).toBe(true);
      expect(result.contradictingReferences.length).toBeGreaterThan(0);
    });

    it("should use provided references if available", async () => {
      const mockReferences: Reference[] = [
        {
          source: "NASA",
          title: "Space Discovery",
          url: "https://nasa.gov",
          snippet: "Recent space discoveries",
          relevance: "neutral",
          category: "Science",
        },
      ];

      const result = await analyzeNewsContent("Space news", "Science", mockReferences);

      expect(result.allReferences).toBeDefined();
      expect(Array.isArray(result.allReferences)).toBe(true);
    });

    it("should handle different news categories", async () => {
      const categories = ["Sports", "Education", "Science", "Politics", "Companies", "Entertainment", "Other"];

      for (const category of categories) {
        const result = await analyzeNewsContent(`Test news in ${category}`, category);
        expect(result.confidencePercentage).toBeGreaterThanOrEqual(0);
        expect(result.confidencePercentage).toBeLessThanOrEqual(100);
      }
    });

    it("should return analysis with proper structure", async () => {
      const result = await analyzeNewsContent("Test news", "Science");

      expect(typeof result.confidencePercentage).toBe("number");
      expect(typeof result.isLikelyFake).toBe("boolean");
      expect(typeof result.analysis).toBe("string");
      expect(Array.isArray(result.supportingReferences)).toBe(true);
      expect(Array.isArray(result.contradictingReferences)).toBe(true);
      expect(Array.isArray(result.allReferences)).toBe(true);
    });
  });
});
