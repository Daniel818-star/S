import { invokeLLM } from "./_core/llm";
import { callDataApi } from "./_core/dataApi";

export interface Reference {
  source: string;
  title: string;
  url: string;
  snippet: string;
  relevance: "supporting" | "contradicting" | "neutral";
  category: string;
}

export interface AnalysisResult {
  confidencePercentage: number;
  isLikelyFake: boolean;
  analysis: string;
  supportingReferences: Reference[];
  contradictingReferences: Reference[];
  allReferences: Reference[];
}

// Category-specific reference sources
const REFERENCE_SOURCES: Record<string, string[]> = {
  Sports: ["FIFA", "Marca", "ESPN", "BBC Sport", "Sky Sports", "Goal.com", "The Athletic"],
  Education: [
    "UNESCO",
    "MIT",
    "Harvard",
    "Stanford",
    "Oxford",
    "Cambridge",
    "Education Week",
    "The Chronicle of Higher Education",
  ],
  Science: ["NASA", "Nature", "Science Magazine", "PNAS", "Scientific American", "MIT News", "Caltech"],
  Politics: ["BBC", "CNN", "Reuters", "AP News", "The Guardian", "The New York Times", "Washington Post"],
  Companies: [
    "Bloomberg",
    "Reuters",
    "Financial Times",
    "Wall Street Journal",
    "SEC",
    "CNBC",
    "MarketWatch",
  ],
  Entertainment: [
    "Variety",
    "The Hollywood Reporter",
    "Deadline",
    "Entertainment Weekly",
    "Rolling Stone",
    "Vanity Fair",
  ],
  Other: ["BBC", "Reuters", "AP News", "The Guardian", "NPR"],
};

/**
 * Query authoritative sources for a given news item and category
 */
async function queryReferenceSources(
  newsContent: string,
  category: string,
  maxResults: number = 10
): Promise<Reference[]> {
  const sources = REFERENCE_SOURCES[category] || REFERENCE_SOURCES.Other;
  const references: Reference[] = [];

  try {
    // Build search query with source constraints
    const searchQuery = `${newsContent} ${sources.slice(0, 3).join(" OR ")}`;

    // Use data API to search for references
    const results = await callDataApi("Google/search", {
      query: {
        q: searchQuery,
        num: maxResults,
      },
    });

    if (results && typeof results === "object") {
      const searchResults = (results as Record<string, unknown>).results;
      if (Array.isArray(searchResults)) {
        for (const result of searchResults) {
          if (typeof result === "object" && result !== null) {
            const r = result as Record<string, unknown>;
            references.push({
              source: (r.source as string) || "Unknown",
              title: (r.title as string) || "",
              url: (r.url as string) || "",
              snippet: (r.snippet as string) || (r.description as string) || "",
              relevance: "neutral",
              category,
            });
          }
        }
      }
    }
  } catch (error) {
    console.error(`[FakeNewsDetection] Failed to query references for ${category}:`, error);
  }

  return references;
}

/**
 * Extract text from image using LLM vision capabilities
 */
export async function extractTextFromImage(imageUrl: string): Promise<string> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image_url",
              image_url: {
                url: imageUrl,
                detail: "high",
              },
            },
            {
              type: "text",
              text: "Please extract and transcribe all text visible in this image. Return only the extracted text without any additional commentary.",
            },
          ],
        },
      ],
    });

    if (response.choices?.[0]?.message?.content) {
      return typeof response.choices[0].message.content === "string"
        ? response.choices[0].message.content
        : "";
    }
    return "";
  } catch (error) {
    console.error("[FakeNewsDetection] Failed to extract text from image:", error);
    throw error;
  }
}

/**
 * Analyze news content for fake news indicators using LLM and reference verification
 */
export async function analyzeNewsContent(
  newsContent: string,
  category: string,
  references: Reference[] = []
): Promise<AnalysisResult> {
  try {
    // If no references provided, query them
    let allReferences = references;
    if (allReferences.length === 0) {
      allReferences = await queryReferenceSources(newsContent, category);
    }

    // Build reference context for LLM
    const referenceContext =
      allReferences.length > 0
        ? `\n\nAvailable references:\n${allReferences
            .map(
              (ref, idx) =>
                `${idx + 1}. ${ref.source}: "${ref.title}" - ${ref.snippet.substring(0, 200)}`
            )
            .join("\n")}`
        : "";

    const systemPrompt = `You are an expert fact-checker and misinformation analyst. Your task is to analyze news claims and determine their veracity. 

For the given news claim in the "${category}" category, you must:
1. Assess the likelihood that this news is fake (0-100 confidence percentage)
2. Provide a detailed analysis explaining your reasoning
3. Identify which references support or contradict the claim
4. Consider common misinformation patterns, logical fallacies, and factual inconsistencies

Respond in JSON format with the following structure:
{
  "confidencePercentage": <number 0-100>,
  "isLikelyFake": <boolean>,
  "analysis": "<detailed explanation>",
  "supportingReferenceIndices": [<array of reference indices that support the claim>],
  "contradictingReferenceIndices": [<array of reference indices that contradict the claim>]
}

A higher confidence percentage means you are MORE confident the news is FAKE.
A lower confidence percentage means you are MORE confident the news is REAL.`;

    const userPrompt = `Analyze this news claim from the ${category} category:\n\n"${newsContent}"${referenceContext}`;

    // Call LLM for analysis
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: userPrompt,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "news_analysis",
          strict: true,
          schema: {
            type: "object",
            properties: {
              confidencePercentage: {
                type: "integer",
                description: "Confidence that the news is fake (0-100)",
              },
              isLikelyFake: {
                type: "boolean",
                description: "Whether the news is likely fake",
              },
              analysis: {
                type: "string",
                description: "Detailed analysis explanation",
              },
              supportingReferenceIndices: {
                type: "array",
                items: { type: "integer" },
                description: "Indices of references that support the claim",
              },
              contradictingReferenceIndices: {
                type: "array",
                items: { type: "integer" },
                description: "Indices of references that contradict the claim",
              },
            },
            required: [
              "confidencePercentage",
              "isLikelyFake",
              "analysis",
              "supportingReferenceIndices",
              "contradictingReferenceIndices",
            ],
            additionalProperties: false,
          },
        },
      },
    });

    // Parse the response
    let analysisData;
    if (response.choices?.[0]?.message?.content) {
      const content = response.choices[0].message.content;
      analysisData =
        typeof content === "string" ? JSON.parse(content) : content;
    } else {
      throw new Error("No response from LLM");
    }

    // Build supporting and contradicting references
    const supportingReferences: Reference[] = [];
    const contradictingReferences: Reference[] = [];

    if (Array.isArray(analysisData.supportingReferenceIndices)) {
      analysisData.supportingReferenceIndices.forEach((idx: number) => {
        if (allReferences[idx]) {
          supportingReferences.push({
            ...allReferences[idx],
            relevance: "supporting",
          });
        }
      });
    }

    if (Array.isArray(analysisData.contradictingReferenceIndices)) {
      analysisData.contradictingReferenceIndices.forEach((idx: number) => {
        if (allReferences[idx]) {
          contradictingReferences.push({
            ...allReferences[idx],
            relevance: "contradicting",
          });
        }
      });
    }

    return {
      confidencePercentage: analysisData.confidencePercentage,
      isLikelyFake: analysisData.isLikelyFake,
      analysis: analysisData.analysis,
      supportingReferences,
      contradictingReferences,
      allReferences,
    };
  } catch (error) {
    console.error("[FakeNewsDetection] Failed to analyze news content:", error);
    throw error;
  }
}
