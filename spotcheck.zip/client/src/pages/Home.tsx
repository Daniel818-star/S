import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, CheckCircle2, Upload, Loader2, Search, Moon, Sun, LogOut } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { useTheme } from "@/contexts/ThemeContext";

const CATEGORIES = ["Sports", "Education", "Science", "Politics", "Companies", "Entertainment", "Other"];

interface AnalysisResult {
  id: number;
  confidencePercentage: number;
  isLikelyFake: boolean;
  analysis: string;
  supportingReferences: any[];
  contradictingReferences: any[];
  allReferences: any[];
}

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [, navigate] = useLocation();
  const [newsText, setNewsText] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Other");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  const submitAnalysisMutation = trpc.analysis.submit.useMutation();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      navigate("/");
    },
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setImagePreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitAnalysis = async (isImageMode: boolean) => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    if (isImageMode && !imageFile) {
      toast.error("Please upload an image");
      return;
    }

    if (!isImageMode && !newsText.trim()) {
      toast.error("Please enter news text to analyze");
      return;
    }

    setIsAnalyzing(true);
    try {
      let imageUrl = "";

      // If image mode, upload to storage first
      if (isImageMode && imageFile) {
        const formData = new FormData();
        formData.append("file", imageFile);

        const uploadResponse = await fetch("/api/upload", {
          method: "POST",
          body: formData,
        });

        if (!uploadResponse.ok) {
          throw new Error("Failed to upload image");
        }

        const { url } = await uploadResponse.json();
        imageUrl = url;
      }

      const result = await submitAnalysisMutation.mutateAsync({
        content: isImageMode ? "" : newsText,
        category: selectedCategory as "Sports" | "Education" | "Science" | "Politics" | "Companies" | "Entertainment" | "Other",
        isImageUpload: isImageMode,
        imageUrl: isImageMode ? imageUrl : undefined,
      });

      setAnalysisResult(result as AnalysisResult);
      toast.success("Analysis completed!");

      // Reset form
      if (isImageMode) {
        setImageFile(null);
        setImagePreview(null);
      } else {
        setNewsText("");
      }
    } catch (error) {
      console.error("Analysis error:", error);
      toast.error("Failed to analyze news. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663571686217/SmHfw5bjthwjnxMTMattGp/spotcheck-logo-PckJoZVAbXKxp4iQwhfz5u.webp"
              alt="SpotCheck"
              className="h-10 w-10"
            />
            <h1 className="text-2xl font-bold text-foreground">SpotCheck</h1>
          </div>

          <div className="flex items-center gap-4">
            {toggleTheme && (
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleTheme}
                title="Toggle theme"
              >
                {theme === "light" ? (
                  <Moon className="h-4 w-4" />
                ) : (
                  <Sun className="h-4 w-4" />
                )}
              </Button>
            )}
            {isAuthenticated ? (
              <>
                <span className="text-sm text-muted-foreground">Welcome, {user?.name}</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("/history")}
                >
                  History
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => logoutMutation.mutate()}
                  disabled={logoutMutation.isPending}
                >
                  {logoutMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <LogOut className="h-4 w-4" />
                  )}
                </Button>
              </>
            ) : (
              <Button
                size="sm"
                onClick={() => {
                  window.location.href = getLoginUrl();
                }}
              >
                Sign In
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="mb-12 text-center">
          <h2 className="text-4xl font-bold mb-4 text-foreground">
            Detect Fake News with AI
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            SpotCheck uses advanced AI and real-time reference verification to analyze news claims across multiple authoritative sources. Get confidence scores and detailed analysis instantly.
          </p>
        </div>

        {/* Analysis Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Input Card */}
          <div className="lg:col-span-2">
            <Card className="border-border shadow-lg">
              <CardHeader>
                <CardTitle>Analyze News</CardTitle>
                <CardDescription>
                  Submit text or upload an image to verify news authenticity
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="text" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="text">Text Input</TabsTrigger>
                    <TabsTrigger value="image">Upload Image</TabsTrigger>
                  </TabsList>

                  {/* Text Tab */}
                  <TabsContent value="text" className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="news-text">News Content</Label>
                      <Textarea
                        id="news-text"
                        placeholder="Paste the news article or claim you want to verify..."
                        value={newsText}
                        onChange={(e) => setNewsText(e.target.value)}
                        className="min-h-32 resize-none"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="category">Category</Label>
                      <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                        <SelectTrigger id="category">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map((cat) => (
                            <SelectItem key={cat} value={cat}>
                              {cat}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <Button
                      onClick={() => handleSubmitAnalysis(false)}
                      disabled={isAnalyzing || !newsText.trim()}
                      className="w-full"
                      size="lg"
                    >
                      {isAnalyzing ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Search className="mr-2 h-4 w-4" />
                          Analyze News
                        </>
                      )}
                    </Button>
                  </TabsContent>

                  {/* Image Tab */}
                  <TabsContent value="image" className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="image-upload">Upload Image</Label>
                      <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-accent/50 transition-colors">
                        <Upload className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                        <p className="text-sm text-muted-foreground mb-2">
                          Drag and drop an image, or click to select
                        </p>
                        <Input
                          id="image-upload"
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => document.getElementById("image-upload")?.click()}
                        >
                          Select Image
                        </Button>
                      </div>

                      {imagePreview && (
                        <div className="mt-4">
                          <p className="text-sm font-medium mb-2">Preview:</p>
                          <img
                            src={imagePreview}
                            alt="Preview"
                            className="max-h-48 rounded-lg border border-border"
                          />
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="category-image">Category</Label>
                      <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                        <SelectTrigger id="category-image">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map((cat) => (
                            <SelectItem key={cat} value={cat}>
                              {cat}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <Button
                      onClick={() => handleSubmitAnalysis(true)}
                      disabled={isAnalyzing || !imageFile}
                      className="w-full"
                      size="lg"
                    >
                      {isAnalyzing ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Search className="mr-2 h-4 w-4" />
                          Analyze Image
                        </>
                      )}
                    </Button>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Info Cards */}
          <div className="space-y-4">
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="text-base">How It Works</CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-3 text-muted-foreground">
                <div className="flex gap-2">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center text-xs font-bold text-accent">
                    1
                  </div>
                  <p>Submit news text or upload an image</p>
                </div>
                <div className="flex gap-2">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center text-xs font-bold text-accent">
                    2
                  </div>
                  <p>AI analyzes the content and queries authoritative sources</p>
                </div>
                <div className="flex gap-2">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center text-xs font-bold text-accent">
                    3
                  </div>
                  <p>Get confidence score and detailed analysis</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <CardTitle className="text-base">Categories</CardTitle>
              </CardHeader>
              <CardContent className="text-sm">
                <ul className="space-y-2 text-muted-foreground">
                  {CATEGORIES.map((cat) => (
                    <li key={cat} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent" />
                      {cat}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Results Section */}
        {analysisResult && (
          <Card className="border-border shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Analysis Results</CardTitle>
                {analysisResult.isLikelyFake ? (
                  <AlertCircle className="h-6 w-6 text-destructive" />
                ) : (
                  <CheckCircle2 className="h-6 w-6 text-green-500" />
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Confidence Score */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Confidence Score</Label>
                  <span className="text-2xl font-bold text-accent">
                    {analysisResult.confidencePercentage}%
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                  <div
                    className={`h-full transition-all ${
                      analysisResult.confidencePercentage > 70
                        ? "bg-destructive"
                        : analysisResult.confidencePercentage > 40
                          ? "bg-warning"
                          : "bg-green-500"
                    }`}
                    style={{ width: `${analysisResult.confidencePercentage}%` }}
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  {analysisResult.isLikelyFake
                    ? "This news appears to be likely fake or misleading"
                    : "This news appears to be likely authentic"}
                </p>
              </div>

              {/* Analysis */}
              <div className="space-y-2">
                <Label>Detailed Analysis</Label>
                <p className="text-sm text-foreground leading-relaxed bg-card p-4 rounded-lg border border-border">
                  {analysisResult.analysis}
                </p>
              </div>

              {/* Supporting References */}
              {analysisResult.supportingReferences.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-green-600 dark:text-green-400">
                    Supporting References ({analysisResult.supportingReferences.length})
                  </Label>
                  <div className="space-y-2">
                    {analysisResult.supportingReferences.map((ref, idx) => (
                      <div key={idx} className="p-3 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-900">
                        <p className="font-medium text-sm text-foreground">{ref.title}</p>
                        <p className="text-xs text-muted-foreground mt-1">{ref.source}</p>
                        <p className="text-sm text-foreground mt-2">{ref.snippet}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Contradicting References */}
              {analysisResult.contradictingReferences.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-destructive">
                    Contradicting References ({analysisResult.contradictingReferences.length})
                  </Label>
                  <div className="space-y-2">
                    {analysisResult.contradictingReferences.map((ref, idx) => (
                      <div key={idx} className="p-3 bg-red-50 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-900">
                        <p className="font-medium text-sm text-foreground">{ref.title}</p>
                        <p className="text-xs text-muted-foreground mt-1">{ref.source}</p>
                        <p className="text-sm text-foreground mt-2">{ref.snippet}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <Button
                onClick={() => navigate("/history")}
                variant="outline"
                className="w-full"
              >
                View Full History
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
