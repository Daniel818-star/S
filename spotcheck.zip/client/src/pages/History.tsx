import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle2, Trash2, ArrowLeft, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useLocation } from "wouter";

interface Analysis {
  id: number;
  originalContent: string;
  category: string;
  confidencePercentage: number;
  isLikelyFake: number;
  analysis: string;
  supportingReferences: any[];
  contradictingReferences: any[];
  createdAt: Date;
}

export default function History() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [selectedAnalysis, setSelectedAnalysis] = useState<Analysis | null>(null);

  const historyQuery = trpc.analysis.history.useQuery({
    limit: 50,
    offset: 0,
  });

  const deleteAnalysisMutation = trpc.analysis.delete.useMutation({
    onSuccess: () => {
      toast.success("Analysis deleted");
      historyQuery.refetch();
      setSelectedAnalysis(null);
    },
    onError: () => {
      toast.error("Failed to delete analysis");
    },
  });

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/");
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  const analyses = (historyQuery.data || []) as Analysis[];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/")}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <h1 className="text-2xl font-bold text-foreground">Search History</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* History List */}
          <div className="lg:col-span-2">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Past Analyses</CardTitle>
                <CardDescription>
                  {analyses.length} analysis results found
                </CardDescription>
              </CardHeader>
              <CardContent>
                {historyQuery.isLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : analyses.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">No analyses yet. Start by analyzing some news!</p>
                    <Button
                      onClick={() => navigate("/")}
                      className="mt-4"
                    >
                      Analyze News
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {analyses.map((analysis) => (
                      <div
                        key={analysis.id}
                        onClick={() => setSelectedAnalysis(analysis)}
                        className={`p-4 rounded-lg border cursor-pointer transition-all ${
                          selectedAnalysis?.id === analysis.id
                            ? "border-accent bg-accent/5"
                            : "border-border hover:border-accent/50"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant="outline">{analysis.category}</Badge>
                              {analysis.isLikelyFake ? (
                                <AlertCircle className="h-4 w-4 text-destructive" />
                              ) : (
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                              )}
                            </div>
                            <p className="text-sm font-medium text-foreground truncate">
                              {analysis.originalContent.substring(0, 100)}...
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(analysis.createdAt).toLocaleDateString()} at{" "}
                              {new Date(analysis.createdAt).toLocaleTimeString()}
                            </p>
                          </div>
                          <div className="flex-shrink-0 text-right">
                            <div className="text-lg font-bold text-accent">
                              {analysis.confidencePercentage}%
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Detail View */}
          <div>
            {selectedAnalysis ? (
              <Card className="border-border sticky top-24">
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-base">Details</CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        deleteAnalysisMutation.mutate({ id: selectedAnalysis.id });
                      }}
                      disabled={deleteAnalysisMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Confidence */}
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Confidence Score</p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-full ${
                            selectedAnalysis.confidencePercentage > 70
                              ? "bg-destructive"
                              : selectedAnalysis.confidencePercentage > 40
                                ? "bg-warning"
                                : "bg-green-500"
                          }`}
                          style={{ width: `${selectedAnalysis.confidencePercentage}%` }}
                        />
                      </div>
                      <span className="text-sm font-bold text-accent">
                        {selectedAnalysis.confidencePercentage}%
                      </span>
                    </div>
                  </div>

                  {/* Category */}
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Category</p>
                    <Badge>{selectedAnalysis.category}</Badge>
                  </div>

                  {/* Status */}
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Status</p>
                    <p className="text-sm font-medium">
                      {selectedAnalysis.isLikelyFake ? (
                        <span className="text-destructive">Likely Fake</span>
                      ) : (
                        <span className="text-green-600 dark:text-green-400">Likely Authentic</span>
                      )}
                    </p>
                  </div>

                  {/* Analysis */}
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Analysis</p>
                    <p className="text-sm text-foreground leading-relaxed bg-card p-2 rounded border border-border max-h-32 overflow-y-auto">
                      {selectedAnalysis.analysis}
                    </p>
                  </div>

                  {/* References Summary */}
                  <div className="pt-4 border-t border-border">
                    <p className="text-xs text-muted-foreground mb-2">References</p>
                    <div className="space-y-2">
                      {selectedAnalysis.supportingReferences.length > 0 && (
                        <div className="text-xs">
                          <span className="text-green-600 dark:text-green-400 font-medium">
                            Supporting: {selectedAnalysis.supportingReferences.length}
                          </span>
                        </div>
                      )}
                      {selectedAnalysis.contradictingReferences.length > 0 && (
                        <div className="text-xs">
                          <span className="text-destructive font-medium">
                            Contradicting: {selectedAnalysis.contradictingReferences.length}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Date */}
                  <div className="pt-4 border-t border-border">
                    <p className="text-xs text-muted-foreground">
                      {new Date(selectedAnalysis.createdAt).toLocaleString()}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-border">
                <CardContent className="pt-6 text-center">
                  <p className="text-sm text-muted-foreground">
                    Select an analysis to view details
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
