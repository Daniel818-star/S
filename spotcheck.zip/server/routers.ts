import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  analysis: router({
    submit: protectedProcedure
      .input(
        z.object({
          content: z.string().min(10),
          category: z.enum(["Sports", "Education", "Science", "Politics", "Companies", "Entertainment", "Other"]),
          isImageUpload: z.boolean().default(false),
          imageUrl: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { createAnalysis } = await import("./db");
        const { analyzeNewsContent, extractTextFromImage } = await import("./fakeNewsDetection");
        const { storagePut } = await import("./storage");

        let contentToAnalyze = input.content;

        // If image upload, extract text from image first
        if (input.isImageUpload && input.imageUrl) {
          contentToAnalyze = await extractTextFromImage(input.imageUrl);
        }

        // Analyze the content
        const result = await analyzeNewsContent(contentToAnalyze, input.category);

        // Store in database
        const analysis = await createAnalysis({
          userId: ctx.user.id,
          originalContent: contentToAnalyze,
          isImageUpload: input.isImageUpload ? 1 : 0,
          imageUrl: input.imageUrl,
          category: input.category,
          confidencePercentage: result.confidencePercentage,
          isLikelyFake: result.isLikelyFake ? 1 : 0,
          analysis: result.analysis,
          supportingReferences: JSON.stringify(result.supportingReferences),
          contradictingReferences: JSON.stringify(result.contradictingReferences),
          allReferences: JSON.stringify(result.allReferences),
        });

        return {
          id: (analysis as any).insertId,
          ...result,
        };
      }),

    history: protectedProcedure
      .input(
        z.object({
          limit: z.number().default(50),
          offset: z.number().default(0),
        })
      )
      .query(async ({ ctx, input }) => {
        const { getUserAnalyses } = await import("./db");
        const analyses = await getUserAnalyses(ctx.user.id, input.limit, input.offset);
        return analyses.map((a: any) => ({
          ...a,
          supportingReferences: JSON.parse(a.supportingReferences),
          contradictingReferences: JSON.parse(a.contradictingReferences),
          allReferences: JSON.parse(a.allReferences),
        }));
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const { getAnalysisById } = await import("./db");
        const analysis = await getAnalysisById(input.id);
        if (!analysis || analysis.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return {
          ...analysis,
          supportingReferences: JSON.parse(analysis.supportingReferences),
          contradictingReferences: JSON.parse(analysis.contradictingReferences),
          allReferences: JSON.parse(analysis.allReferences),
        };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const { deleteAnalysis } = await import("./db");
        const success = await deleteAnalysis(input.id, ctx.user.id);
        if (!success) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
