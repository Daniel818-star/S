import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * News analysis results table - stores all fake news detection analyses
 */
export const newsAnalyses = mysqlTable("news_analyses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  originalContent: text("originalContent").notNull(), // Original text or extracted image text
  isImageUpload: int("isImageUpload").default(0).notNull(), // 0 = text, 1 = image
  imageUrl: text("imageUrl"), // URL to uploaded image if applicable
  category: varchar("category", { length: 50 }).notNull(), // Sports, Education, Science, Politics, Companies, Entertainment, Other
  confidencePercentage: int("confidencePercentage").notNull(), // 0-100
  isLikelyFake: int("isLikelyFake").notNull(), // 0 = likely real, 1 = likely fake
  analysis: text("analysis").notNull(), // Detailed LLM analysis
  supportingReferences: text("supportingReferences").notNull(), // JSON array of supporting sources
  contradictingReferences: text("contradictingReferences").notNull(), // JSON array of contradicting sources
  allReferences: text("allReferences").notNull(), // JSON array of all queried references with details
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NewsAnalysis = typeof newsAnalyses.$inferSelect;
export type InsertNewsAnalysis = typeof newsAnalyses.$inferInsert;