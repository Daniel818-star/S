import { Router, Request, Response } from "express";
import { storagePut } from "./storage";

const uploadRouter = Router();

// Middleware to parse multipart form data
uploadRouter.post("/upload", async (req: Request, res: Response) => {
  try {
    // Check if file is present
    const files = (req as any).files;
    if (!files || Object.keys(files).length === 0) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const file = files.file as any;

    // Validate file type
    const allowedMimes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
    if (!allowedMimes.includes(file.mimetype)) {
      return res.status(400).json({ error: "Invalid file type. Only images are allowed." });
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return res.status(400).json({ error: "File size exceeds 10MB limit" });
    }

    // Get user ID from session (assumes auth middleware is applied)
    const userId = (req as any).user?.id;
    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    // Upload to storage
    const filename = `${userId}-${Date.now()}-${file.name}`;
    const { url, key } = await storagePut(filename, file.data, file.mimetype);

    return res.json({
      url,
      key,
      filename: file.name,
      size: file.size,
    });
  } catch (error) {
    console.error("[Upload] Error:", error);
    return res.status(500).json({ error: "Upload failed" });
  }
});

export default uploadRouter;
