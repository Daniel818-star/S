CREATE TABLE `news_analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`originalContent` text NOT NULL,
	`isImageUpload` int NOT NULL DEFAULT 0,
	`imageUrl` text,
	`category` varchar(50) NOT NULL,
	`confidencePercentage` int NOT NULL,
	`isLikelyFake` int NOT NULL,
	`analysis` text NOT NULL,
	`supportingReferences` text NOT NULL,
	`contradictingReferences` text NOT NULL,
	`allReferences` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `news_analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `news_analyses` ADD CONSTRAINT `news_analyses_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;