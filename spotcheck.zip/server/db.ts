import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, newsAnalyses, InsertNewsAnalysis } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserAnalyses(userId: number, limit: number = 50, offset: number = 0) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get analyses: database not available");
    return [];
  }

  const result = await db
    .select()
    .from(newsAnalyses)
    .where(eq(newsAnalyses.userId, userId))
    .orderBy(desc(newsAnalyses.createdAt))
    .limit(limit)
    .offset(offset);

  return result;
}

export async function createAnalysis(analysis: InsertNewsAnalysis) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create analysis: database not available");
    return null;
  }

  try {
    const result = await db.insert(newsAnalyses).values(analysis);
    return result;
  } catch (error) {
    console.error("[Database] Failed to create analysis:", error);
    throw error;
  }
}

export async function getAnalysisById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get analysis: database not available");
    return null;
  }

  const result = await db
    .select()
    .from(newsAnalyses)
    .where(eq(newsAnalyses.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function deleteAnalysis(id: number, userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete analysis: database not available");
    return false;
  }

  try {
    // First check if the analysis exists and belongs to the user
    const analysis = await db
      .select()
      .from(newsAnalyses)
      .where(and(eq(newsAnalyses.id, id), eq(newsAnalyses.userId, userId)))
      .limit(1);

    if (analysis.length === 0) {
      return false; // Analysis not found or doesn't belong to user
    }

    await db
      .delete(newsAnalyses)
      .where(and(eq(newsAnalyses.id, id), eq(newsAnalyses.userId, userId)));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete analysis:", error);
    throw error;
  }
}

// TODO: add feature queries here as your schema grows.
